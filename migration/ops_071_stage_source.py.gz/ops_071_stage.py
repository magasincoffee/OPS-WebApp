#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv, hashlib, json, re, unicodedata, uuid, zipfile
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
import xml.etree.ElementTree as ET

NS_MAIN='http://schemas.openxmlformats.org/spreadsheetml/2006/main'
NS_REL='http://schemas.openxmlformats.org/officeDocument/2006/relationships'
NS_PKG='http://schemas.openxmlformats.org/package/2006/relationships'
Q=lambda tag:f'{{{NS_MAIN}}}{tag}'
R_ID=f'{{{NS_REL}}}id'
PLACEHOLDERS={'','-','--','???','#N/A','#REF!'}
MIGRATION_NS=uuid.uuid5(uuid.NAMESPACE_URL,'https://github.com/magasincoffee/OPS-WebApp/OPS-071')

SOURCE_IDS={
 'thu_chi':'1Y0oCJ1gxsBwFI2c6N-_ueMfDmqV29evLlNB_YJIX2GQ',
 'gia_von':'1E7sj2w2-vFp7kHvk7eAqIwJ1F8zLDq-Einj2w7SWx_Y',
}

STATUS_MAP={
 'ĐÃ THU': {'payment':'PAID'},
 'CHỜ GIAO': {'delivery':'READY'},
 'CHỜ IN': {'print':'WAITING'},
 'ĐÃ GIAO - CHƯA THU': {'delivery':'COMPLETED','payment':'RECEIVABLE'},
 'ĐÃ THU - CHỜ GIAO': {'payment':'PAID','delivery':'READY'},
}

QUARANTINE_CODES={
 'REVIEW_CUSTOMER_CONFLICT','REVIEW_SUPPLIER_DUPLICATE','REVIEW_MISSING_SKU_MASTER',
 'REVIEW_MISSING_SKU_ORDER_LINE','REVIEW_DUPLICATE_SKU','REVIEW_PACKAGING',
 'REVIEW_COST_COMPONENTS','REVIEW_PRICE_BLOCK','REVIEW_STATUS','REVIEW_ORDER_CONFLICT',
 'REVIEW_PO_CONFLICT','REVIEW_ORPHAN_RECEIPT','REVIEW_PAYMENT_LINK','REVIEW_NEGATIVE_STOCK',
 'REVIEW_OPENING_BALANCE','REVIEW_SPREADSHEET_ERROR'
}


def clean_text(v):
    if v is None: return None
    s=unicodedata.normalize('NFC',str(v)).replace('\r\n','\n').replace('\r','\n')
    s='\n'.join(re.sub(r'[ \t]+',' ',line).strip() for line in s.split('\n')).strip()
    return s or None

def key_text(v):
    s=clean_text(v)
    return s.casefold() if s else None

def is_placeholder(v):
    s=clean_text(v)
    return s is None or s.upper() in PLACEHOLDERS

def ascii_slug(v):
    s=unicodedata.normalize('NFKD',clean_text(v) or '')
    s=''.join(ch for ch in s if not unicodedata.combining(ch))
    s=re.sub(r'[^A-Za-z0-9]+','-',s).strip('-').upper()
    return (s[:36] or 'ITEM')

def stable_uuid(kind,key):
    return str(uuid.uuid5(MIGRATION_NS,kind+'|'+str(key)))

def sha256_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def dec(v):
    if v is None or is_placeholder(v): return None
    if isinstance(v,(int,float,Decimal)): return Decimal(str(v))
    s=clean_text(v)
    if not s: return None
    s=s.replace('đ','').replace('Đ','').replace('%','').replace(' ','')
    try:
        if re.fullmatch(r'-?\d{1,3}(?:\.\d{3})+',s): s=s.replace('.','')
        elif re.fullmatch(r'-?\d{1,3}(?:,\d{3})+',s): s=s.replace(',','')
        elif ',' in s and '.' not in s: s=s.replace(',','.')
        return Decimal(s)
    except InvalidOperation:
        return None

def num(v):
    d=dec(v)
    return float(d) if d is not None else None

def intish(v):
    d=dec(v)
    if d is None: return None
    return int(d) if d==d.to_integral_value() else None

def json_num(v):
    if isinstance(v,Decimal): return int(v) if v==v.to_integral_value() else float(v)
    return v

def json_default(v):
    if isinstance(v,(datetime,)): return v.isoformat()
    if isinstance(v,Decimal): return json_num(v)
    return str(v)

def parse_date(v):
    if v is None or is_placeholder(v): return None
    if isinstance(v,datetime): return v.date().isoformat()
    s=clean_text(v)
    if not s: return None
    for fmt in ('%d/%m/%Y','%d/%m/%y','%Y-%m-%d'):
        try:return datetime.strptime(s,fmt).date().isoformat()
        except ValueError:pass
    return None

def source_ref(file_id,sheet,row): return f'gdrive:{file_id}/{sheet}/R{row}'
def generated_sku(file_id,sheet,row,name,package):
    raw=f'{file_id}|{sheet}|{row}|{clean_text(name) or ""}|{clean_text(package) or ""}'
    return f'MIG-{ascii_slug(name)}-{hashlib.sha256(raw.encode()).hexdigest()[:8]}'
def supplier_code(name): return 'MIG-SUP-'+hashlib.sha256((key_text(name) or '').encode()).hexdigest()[:8]

def parse_packaging(v):
    s=clean_text(v)
    if not s:return None
    m=re.fullmatch(r'([\d.,]+)\s*(?:cái|cay|chiếc|pcs?)\s*/\s*([^/]+)',s,re.I)
    if not m:return None
    units=dec(m.group(1))
    if units is None or units<=0:return None
    unit=clean_text(m.group(2))
    if not unit:return None
    return {'units_per_package':json_num(units),'package_name':unit,'package_code':ascii_slug(unit)[:20]}

class XlsxReader:
    def __init__(self,path):
        self.path=Path(path); self.z=zipfile.ZipFile(self.path)
        self.shared=self._shared(); self.styles=self._styles(); self.sheets=self._sheets()
    def _shared(self):
        if 'xl/sharedStrings.xml' not in self.z.namelist():return []
        root=ET.fromstring(self.z.read('xl/sharedStrings.xml'))
        return [''.join(t.text or '' for t in si.iter(Q('t'))) for si in root]
    def _styles(self):
        if 'xl/styles.xml' not in self.z.namelist():return []
        root=ET.fromstring(self.z.read('xl/styles.xml'))
        custom={int(x.attrib['numFmtId']):x.attrib.get('formatCode','') for x in root.findall('.//'+Q('numFmt'))}
        xfs=root.find(Q('cellXfs')); out=[]
        for xf in (list(xfs) if xfs is not None else []):
            nid=int(xf.attrib.get('numFmtId','0')); code=custom.get(nid,'')
            isdate=nid in set(range(14,23))|{45,46,47} or bool(re.search(r'(^|[^a-z])[dmyhs]+',code.lower()))
            out.append(isdate)
        return out
    def _sheets(self):
        wb=ET.fromstring(self.z.read('xl/workbook.xml')); rels=ET.fromstring(self.z.read('xl/_rels/workbook.xml.rels'))
        relmap={r.attrib['Id']:r.attrib['Target'] for r in rels}
        return {s.attrib['name']:'xl/'+relmap[s.attrib[R_ID]] for s in wb.find(Q('sheets'))}
    @staticmethod
    def _col(ref):
        m=re.match(r'([A-Z]+)',ref); n=0
        for ch in m.group(1):n=n*26+ord(ch)-64
        return n
    def rows(self,sheet):
        root=ET.fromstring(self.z.read(self.sheets[sheet])); data=root.find(Q('sheetData'))
        for row in (list(data) if data is not None else []):
            rno=int(row.attrib['r']); vals={}; errs=[]
            for c in row:
                col=self._col(c.attrib['r']); typ=c.attrib.get('t'); style=int(c.attrib.get('s','0')); v=c.find(Q('v')); raw=v.text if v is not None else None
                if typ=='s' and raw is not None: val=self.shared[int(raw)]
                elif typ=='inlineStr': val=''.join(t.text or '' for t in c.iter(Q('t')))
                elif typ=='b': val=(raw=='1')
                elif typ=='e': val=raw; errs.append(c.attrib['r'])
                elif raw is None: val=None
                else:
                    try:
                        n=float(raw)
                        if style<len(self.styles) and self.styles[style]:
                            val=datetime(1899,12,30)+timedelta(days=n)
                        else: val=int(n) if n.is_integer() else n
                    except ValueError: val=raw
                vals[col]=val
            yield rno,vals,errs
    def close(self):self.z.close()

class Stage:
    def __init__(self):
        self.records=defaultdict(list); self.quarantine=[]; self.controls=Counter(); self.status_values=Counter()
    def add(self,entity,row): self.records[entity].append(row)
    def q(self,reason,ref,message,raw=None):
        assert reason in QUARANTINE_CODES
        self.quarantine.append({'reason':reason,'source_row_reference':ref,'message':message,'raw':raw or {}})
    def control(self,sheet,kind,n=1): self.controls[(sheet,kind)]+=n

def row_dict(vals,headers):
    return {headers[i-1]:vals.get(i) for i in range(1,len(headers)+1) if headers[i-1]}

def run(thu_path,gia_path,out_dir,snapshot_meta):
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    stage=Stage(); thu=XlsxReader(thu_path); gia=XlsxReader(gia_path)

    min_stock=Decimal('0')
    for r,vals,errs in thu.rows('THAM SỐ'):
        if r<3:continue
        if key_text(vals.get(1))=='min_stock' and dec(vals.get(3)) is not None:min_stock=dec(vals.get(3));break

    # Customers
    headers=['Người liên hệ','Mã KH','Tên THƯƠNG HIỆU','Số điện thoại','Địa chỉ','Mã số thuế','Hạn mức công nợ','GIAO DỊCH GẦN NHẤT','Ghi chú']
    cust_by_code={}; phone_owner={}
    for r,vals,errs in thu.rows('KHÁCH HÀNG'):
        if r==1:continue
        ref=source_ref(SOURCE_IDS['thu_chi'],'KHÁCH HÀNG',r); d=row_dict(vals,headers)
        if not any(not is_placeholder(x) for x in d.values()): stage.control('KHÁCH HÀNG','blank');continue
        stage.control('KHÁCH HÀNG','business')
        if errs:stage.q('REVIEW_SPREADSHEET_ERROR',ref,'Spreadsheet error cell in customer row',{'cells':errs});continue
        code=clean_text(d['Mã KH']); brand=clean_text(d['Tên THƯƠNG HIỆU']); contact=clean_text(d['Người liên hệ']); phone=clean_text(d['Số điện thoại']); address=clean_text(d['Địa chỉ'])
        if is_placeholder(code):code=None
        if is_placeholder(phone):phone=None
        display=brand if not is_placeholder(brand) else contact
        if not display:stage.q('REVIEW_CUSTOMER_CONFLICT',ref,'Customer has no usable display/contact name',d);continue
        key=key_text(code) or ('phone:'+key_text(phone) if phone else 'ref:'+ref)
        if code and key in cust_by_code:
            prev=cust_by_code[key]
            if key_text(prev['display_name'])!=key_text(display) or key_text(prev.get('address'))!=key_text(address):
                stage.q('REVIEW_CUSTOMER_CONFLICT',ref,'Duplicate customer code has conflicting attributes',d);continue
            stage.control('KHÁCH HÀNG','dedup_alias');continue
        if phone:
            pk=key_text(phone)
            if pk in phone_owner and phone_owner[pk]!=key:
                stage.q('REVIEW_CUSTOMER_CONFLICT',ref,'Normalized phone maps to multiple customer identities',d);continue
            phone_owner[pk]=key
        cid=stable_uuid('customer',code or ref)
        rec={'id':cid,'customer_code':code,'display_name':display,'brand_name':None if is_placeholder(brand) else brand,'contact_name':contact,'phone':phone,'address':address,'notes':clean_text(d['Ghi chú']),'legacy_tax_code':clean_text(d['Mã số thuế']),'legacy_credit_limit':json_num(dec(d['Hạn mức công nợ'])),'source_row_reference':ref}
        stage.add('customers',rec); cust_by_code[key]=rec

    # Product master from canonical + conditional secondary sheets.
    product_by_id={}; variants=[]; sku_seen={}; variant_id_seen=set(); name_to_variants=defaultdict(list)
    product_sources=[('BẢNG BÁO GIÁ',gia,8,{'name':2,'sku':3,'group':4,'package':7,'purchase':8,'freight':9,'cost':10,'material':16,'status':23},True),('COST NẮP',gia,2,{'name':2,'sku':3,'group':4,'package':7,'purchase':8,'freight':None,'cost':8,'material':None,'status':None},False),('COST PHỤ KIỆN',gia,2,{'name':2,'sku':3,'group':4,'package':7,'purchase':8,'freight':None,'cost':8,'material':None,'status':None},False)]
    for sheet,book,header_row,cols,canonical in product_sources:
        for r,vals,errs in book.rows(sheet):
            if r<=header_row:continue
            name=clean_text(vals.get(cols['name'])); ref=source_ref(SOURCE_IDS['gia_von'],sheet,r)
            rawsku_header=clean_text(vals.get(cols['sku']))
            if not name or is_placeholder(name) or key_text(name) in {'tên sp','tên sản phẩm'} or key_text(rawsku_header)=='mã sp': continue
            stage.control(sheet,'business')
            if errs:stage.q('REVIEW_SPREADSHEET_ERROR',ref,'Spreadsheet error cell in product row',{'cells':errs})
            rawsku=clean_text(vals.get(cols['sku'])); rawsku=None if is_placeholder(rawsku) else rawsku
            pack=clean_text(vals.get(cols['package'])); parsed_pack=parse_packaging(pack)
            raw_key=key_text(rawsku) if rawsku else None
            sku_conflict=False
            if raw_key:
                prev=sku_seen.get(raw_key)
                if prev and prev!=key_text(name):sku_conflict=True
                else:sku_seen[raw_key]=key_text(name)
            sku=(rawsku.upper() if rawsku and not sku_conflict else generated_sku(SOURCE_IDS['gia_von'],sheet,r,name,pack))
            if rawsku is None: stage.q('REVIEW_MISSING_SKU_MASTER',ref,'Generated deterministic SKU for missing source SKU',{'generated_sku':sku,'name':name})
            elif sku_conflict: stage.q('REVIEW_DUPLICATE_SKU',ref,'Generated deterministic SKU because source SKU is non-unique',{'raw_sku':rawsku,'generated_sku':sku,'name':name})
            group=clean_text(vals.get(cols['group'])); material=clean_text(vals.get(cols['material'])) if cols.get('material') else None
            pid=stable_uuid('product',(key_text(name),key_text(group),key_text(material)))
            if pid not in product_by_id:
                product_by_id[pid]={'id':pid,'name':name,'product_type':None if is_placeholder(group) else group,'description':('Legacy material: '+material) if material and not is_placeholder(material) else None,'source_row_reference':ref}
            vid=stable_uuid('variant',sku)
            if vid in variant_id_seen:
                stage.control(sheet,'dedup_alias')
                continue
            variant_id_seen.add(vid)
            vrec={'id':vid,'product_id':pid,'sku_code':sku,'variant_name':name,'base_inventory_unit':'piece','default_purchase_unit':parsed_pack['package_name'] if parsed_pack else None,'minimum_stock_quantity':json_num(min_stock),'source_row_reference':ref,'legacy_raw_sku':rawsku,'legacy_status':clean_text(vals.get(cols['status'])) if cols.get('status') else None,'source_class':'canonical' if canonical else 'secondary'}
            stage.add('product_variants',vrec); variants.append(vrec); name_to_variants[key_text(name)].append(vrec)
            if parsed_pack:
                pgid=stable_uuid('packaging',vid+'|'+parsed_pack['package_code']+'|'+str(parsed_pack['units_per_package']))
                stage.add('product_packaging',{'id':pgid,'product_variant_id':vid,'package_code':parsed_pack['package_code'],'package_name':parsed_pack['package_name'],'units_per_package':parsed_pack['units_per_package'],'is_purchase_default':canonical,'is_sale_default':False,'source_row_reference':ref})
            else:
                stage.q('REVIEW_PACKAGING',ref,'Packaging string cannot be parsed deterministically',{'packaging':pack,'sku':sku})
                pgid=None
            if canonical and parsed_pack:
                p=dec(vals.get(cols['purchase'])); f=dec(vals.get(cols['freight'])) or Decimal('0'); c=dec(vals.get(cols['cost']))
                if p is not None and p>=0 and f>=0 and c is not None and c>=0:
                    u=Decimal(str(parsed_pack['units_per_package'])); other=(c-p-f)*u
                    if other<0:
                        stage.q('REVIEW_COST_COMPONENTS',ref,'Explicit cost is below purchase+freight; no negative allocation inferred',{'purchase':json_num(p),'freight':json_num(f),'cost':json_num(c)})
                    else:
                        stage.add('purchase_cost_history',{'id':stable_uuid('cost',ref),'product_variant_id':vid,'supplier_id':None,'packaging_id':pgid,'effective_at':snapshot_meta['effective_at'],'purchase_unit':parsed_pack['package_name'],'units_per_purchase_unit':json_num(u),'purchase_price_per_purchase_unit':json_num(p*u),'freight_cost_per_purchase_unit':json_num(f*u),'other_allocated_cost_per_purchase_unit':json_num(other),'inventory_cost_basis_per_base_unit':json_num(c) if c>0 else None,'currency_code':'VND','source_reference':ref,'legacy_supplier_price_gt':json_num(dec(vals.get(5))),'legacy_supplier_price_lt':json_num(dec(vals.get(6)))})
                else:stage.q('REVIEW_COST_COMPONENTS',ref,'Canonical cost row has missing/non-numeric required cost components',{'purchase':vals.get(cols['purchase']),'freight':vals.get(cols['freight']),'cost':vals.get(cols['cost'])})
            if canonical and any(vals.get(i) not in (None,'') for i in range(13,23)):
                stage.q('REVIEW_PRICE_BLOCK',ref,'Quantity price blocks are duplicated/unlabeled; retained for review, not auto-loaded',{'M':vals.get(13),'N':vals.get(14),'O':vals.get(15),'Q':vals.get(17),'R':vals.get(18),'S':vals.get(19),'T':vals.get(20),'U':vals.get(21),'V':vals.get(22)})
    referenced_product_ids={v['product_id'] for v in variants}
    for pid,rec in product_by_id.items():
        if pid in referenced_product_ids:stage.add('products',rec)
    variant_by_sku={key_text(v['sku_code']):v for v in variants}

    # Suppliers from PO and receipts
    supplier_rows=[]
    for sheet,col in [('LÊN ĐƠN NCC',3),('NHẬP KHO',3)]:
        for r,vals,errs in thu.rows(sheet):
            if r==1:continue
            name=clean_text(vals.get(col))
            if name and not is_placeholder(name):supplier_rows.append((name,source_ref(SOURCE_IDS['thu_chi'],sheet,r)))
    suppliers={}
    for name,ref in supplier_rows:
        k=key_text(name)
        if k not in suppliers:
            suppliers[k]={'id':stable_uuid('supplier',k),'supplier_code':supplier_code(name),'supplier_name':name,'source_row_reference':ref}
    for rec in suppliers.values():stage.add('suppliers',rec)

    def resolve_variant(rawsku,name,unit,ref):
        if rawsku and not is_placeholder(rawsku):
            v=variant_by_sku.get(key_text(rawsku))
            if v:return v
        candidates=name_to_variants.get(key_text(name),[])
        if len(candidates)==1:return candidates[0]
        stage.q('REVIEW_MISSING_SKU_ORDER_LINE',ref,'Transaction product cannot resolve to exactly one canonical/secondary variant',{'raw_sku':clean_text(rawsku),'name':clean_text(name),'unit':clean_text(unit),'candidate_count':len(candidates)})
        return None

    # Purchase orders/items
    po_groups=defaultdict(list)
    po_headers=['Mã phiếu đặt hàng','Ngày ngày đặt','Nhà cung cấp','Mã SP','Tên sản phẩm','ĐVT','Số lượng','Đơn giá nhập','Vận chuyển','Ghi chú','Thành tiền','Tổng Tiền Đơn','Ghi chú 2']
    for r,vals,errs in thu.rows('LÊN ĐƠN NCC'):
        if r==1:continue
        d=row_dict(vals,po_headers); ref=source_ref(SOURCE_IDS['thu_chi'],'LÊN ĐƠN NCC',r)
        if not clean_text(d['Mã phiếu đặt hàng']):continue
        stage.control('LÊN ĐƠN NCC','business'); po_groups[key_text(d['Mã phiếu đặt hàng'])].append((r,d,ref,errs))
    po_item_index={}
    for k,rows in po_groups.items():
        dates={parse_date(x[1]['Ngày ngày đặt']) for x in rows}; sups={key_text(x[1]['Nhà cung cấp']) for x in rows}
        if None in dates or len(dates)!=1 or None in sups or len(sups)!=1:
            for _,d,ref,_ in rows:stage.q('REVIEW_PO_CONFLICT',ref,'PO group has conflicting/missing supplier or order date',d)
            continue
        first=rows[0][1]; poid=stable_uuid('purchase_order',k); sup=suppliers[next(iter(sups))]
        stage.add('purchase_orders',{'id':poid,'po_number':clean_text(first['Mã phiếu đặt hàng']),'supplier_id':sup['id'],'status':'ORDERED','order_date':next(iter(dates)),'expected_receipt_date':None,'actual_receipt_date':None,'freight_amount':0,'currency_code':'VND','notes':'Migrated legacy purchase order','source_row_reference':rows[0][2],'legacy_total':json_num(dec(first['Tổng Tiền Đơn']))})
        for r,d,ref,errs in rows:
            v=resolve_variant(d['Mã SP'],d['Tên sản phẩm'],d['ĐVT'],ref)
            q=dec(d['Số lượng']); price=dec(d['Đơn giá nhập']); unit=clean_text(d['ĐVT'])
            if not v or q is None or q<=0 or price is None or price<0 or not unit:
                if v:stage.q('REVIEW_PO_CONFLICT',ref,'PO line has invalid quantity/unit/price',d)
                continue
            itemid=stable_uuid('purchase_order_item',ref)
            stage.add('purchase_order_items',{'id':itemid,'purchase_order_id':poid,'product_variant_id':v['id'],'packaging_id':None,'purchase_unit':unit,'package_quantity':json_num(q),'units_per_purchase_unit':1,'unit_cost_per_purchase_unit':json_num(price),'notes':clean_text(d['Ghi chú']) or clean_text(d['Ghi chú 2']),'source_row_reference':ref,'legacy_line_total':json_num(dec(d['Thành tiền']))})
            po_item_index[(k,key_text(v['sku_code']))]=itemid

    # Goods receipts
    gr_headers=['Mã phiếu nhập','Ngày nhập','Nhà cung cấp','Mã SP','Tên sản phẩm','Số lượng','Đơn giá nhập','Vận chuyển','Giá Vốn','Thành tiền','Tổng Tiền Đơn','Ghi chú']
    gr_groups=defaultdict(list)
    for r,vals,errs in thu.rows('NHẬP KHO'):
        if r==1:continue
        d=row_dict(vals,gr_headers); ref=source_ref(SOURCE_IDS['thu_chi'],'NHẬP KHO',r)
        if not clean_text(d['Mã phiếu nhập']):continue
        stage.control('NHẬP KHO','business'); gr_groups[key_text(d['Mã phiếu nhập'])].append((r,d,ref,errs))
    for k,rows in gr_groups.items():
        dates={parse_date(x[1]['Ngày nhập']) for x in rows}; sups={key_text(x[1]['Nhà cung cấp']) for x in rows}
        first=rows[0][1]
        linked_po=None
        # deterministically link receipt group only if every resolvable line maps to one PO by SKU and supplier.
        candidate_pos=set()
        for _,d,ref,_ in rows:
            v=resolve_variant(d['Mã SP'],d['Tên sản phẩm'],None,ref)
            if v:
                for pok,porows in po_groups.items():
                    if key_text(porows[0][1]['Nhà cung cấp']) in sups and (pok,key_text(v['sku_code'])) in po_item_index:candidate_pos.add(pok)
        if len(candidate_pos)==1:linked_po=stable_uuid('purchase_order',next(iter(candidate_pos)))
        if linked_po is None:
            for _,d,ref,_ in rows:stage.q('REVIEW_ORPHAN_RECEIPT',ref,'Receipt group cannot link deterministically to one migrated PO',{'receipt':d['Mã phiếu nhập'],'supplier':d['Nhà cung cấp']})
            continue
        grid=stable_uuid('goods_receipt',k)
        recv_date=next(iter(dates)) if len(dates)==1 and None not in dates else None
        if not recv_date:
            for _,d,ref,_ in rows:stage.q('REVIEW_ORPHAN_RECEIPT',ref,'Receipt has invalid/conflicting date',d)
            continue
        stage.add('goods_receipts',{'id':grid,'goods_receipt_number':clean_text(first['Mã phiếu nhập']),'purchase_order_id':linked_po,'received_at':recv_date+'T12:00:00+07:00','notes':clean_text(first['Ghi chú']),'source_row_reference':rows[0][2]})
        for _,d,ref,_ in rows:
            v=resolve_variant(d['Mã SP'],d['Tên sản phẩm'],None,ref); q=dec(d['Số lượng'])
            po_key=None
            if v:
                for pok in candidate_pos:
                    if (pok,key_text(v['sku_code'])) in po_item_index:po_key=(pok,key_text(v['sku_code']));break
            if not v or q is None or q<=0 or not po_key:continue
            stage.add('goods_receipt_items',{'id':stable_uuid('goods_receipt_item',ref),'goods_receipt_id':grid,'purchase_order_item_id':po_item_index[po_key],'package_quantity':json_num(q),'units_per_purchase_unit':1,'notes':clean_text(d['Ghi chú']),'source_row_reference':ref,'legacy_unit_cost':json_num(dec(d['Đơn giá nhập'])),'legacy_freight':json_num(dec(d['Vận chuyển'])),'legacy_cost':json_num(dec(d['Giá Vốn'])),'legacy_line_total':json_num(dec(d['Thành tiền']))})

    # Sales orders/items
    so_headers=['Mã đơn hàng','Ngày đặt','Ngày giao','Tên khách hàng','Mã KH','Tên THƯƠNG HIỆU','Số điện thoại','ĐỊA CHỈ','Tên sản phẩm','Mã SP','ĐVT','Số lượng','Đơn giá bán','Thành tiền','TỔNG ĐƠN HÀNG','Trạng thái giao','GHI CHÚ']
    so_groups=defaultdict(list)
    customer_by_code={key_text(c['customer_code']):c for c in stage.records['customers'] if c.get('customer_code')}
    for r,vals,errs in thu.rows('ĐƠN HÀNG'):
        if r==1:continue
        d=row_dict(vals,so_headers); ref=source_ref(SOURCE_IDS['thu_chi'],'ĐƠN HÀNG',r)
        if not clean_text(d['Mã đơn hàng']):continue
        stage.control('ĐƠN HÀNG','business'); so_groups[key_text(d['Mã đơn hàng'])].append((r,d,ref,errs)); st=clean_text(d['Trạng thái giao']);
        if st:stage.status_values[st]+=1
    order_by_number={}
    for k,rows in so_groups.items():
        dates={parse_date(x[1]['Ngày đặt']) for x in rows}; custs={key_text(x[1]['Mã KH']) for x in rows}; totals={dec(x[1]['TỔNG ĐƠN HÀNG']) for x in rows if dec(x[1]['TỔNG ĐƠN HÀNG']) is not None}
        if None in dates or len(dates)!=1 or None in custs or len(custs)!=1 or len(totals)>1:
            for _,d,ref,_ in rows:stage.q('REVIEW_ORDER_CONFLICT',ref,'Order group has conflicting customer/date/order total',d)
            continue
        cust=customer_by_code.get(next(iter(custs)))
        if not cust:
            for _,d,ref,_ in rows:stage.q('REVIEW_ORDER_CONFLICT',ref,'Order customer code not found in canonical customer master',d)
            continue
        raw_statuses={clean_text(x[1]['Trạng thái giao']) for x in rows if clean_text(x[1]['Trạng thái giao'])}
        unknown=[s for s in raw_statuses if s not in STATUS_MAP]
        if unknown:
            for _,d,ref,_ in rows:stage.q('REVIEW_STATUS',ref,'Unknown legacy status label',{'status':d['Trạng thái giao']})
            continue
        hints={}
        for s in raw_statuses:hints.update(STATUS_MAP[s])
        first=rows[0][1]; soid=stable_uuid('sales_order',k); due=parse_date(first['Ngày giao'])
        stage.add('sales_orders',{'id':soid,'order_number':clean_text(first['Mã đơn hàng']),'customer_id':cust['id'],'order_status':'CONFIRMED','order_date':next(iter(dates)),'requested_due_date':due,'currency_code':'VND','notes':clean_text(first['GHI CHÚ']),'legacy_status_hints':hints,'source_row_reference':rows[0][2],'legacy_total':json_num(next(iter(totals))) if totals else None})
        order_by_number[k]={'id':soid,'customer_id':cust['id']}
        for _,d,ref,_ in rows:
            if errs:stage.q('REVIEW_SPREADSHEET_ERROR',ref,'Spreadsheet error cell in sales row',{'cells':errs})
            name=clean_text(d['Tên sản phẩm']); rawsku=clean_text(d['Mã SP']); v=resolve_variant(rawsku,name,d['ĐVT'],ref)
            q=dec(d['Số lượng']); price=dec(d['Đơn giá bán']); line=dec(d['Thành tiền']); unit=clean_text(d['ĐVT'])
            # Negative line is a discount row; V1 target models discount on an item, not a standalone negative-priced variant.
            if price is not None and price<0:
                stage.q('REVIEW_ORDER_CONFLICT',ref,'Negative-price legacy line requires order-level discount allocation review',{'name':name,'amount':json_num(line)});continue
            if not v or q is None or q<=0 or price is None or price<0 or not unit:continue
            # Do not invent print mode from name/notes. Historical migration keeps PLAIN unless explicit print evidence is added later.
            stage.add('sales_order_items',{'id':stable_uuid('sales_order_item',ref),'sales_order_id':soid,'product_variant_id':v['id'],'packaging_id':None,'sale_unit':unit,'sale_quantity':json_num(q),'units_per_sale_unit':1,'unit_price_per_sale_unit':json_num(price),'discount_amount':0,'print_mode':'PLAIN','print_color_count':None,'requested_due_date':due,'notes':clean_text(d['GHI CHÚ']),'source_row_reference':ref,'legacy_line_total':json_num(line)})

    # Payments
    pay_headers=['Mã phiếu thu','Ngày thu','Mã đơn hàng','Mã KH','Tên khách hàng','Số tiền thu','Tổng đơn hàng','Hình thức thanh toán','Người thu']
    for r,vals,errs in thu.rows('THU TIỀN'):
        if r==1:continue
        d=row_dict(vals,pay_headers); ref=source_ref(SOURCE_IDS['thu_chi'],'THU TIỀN',r)
        if not clean_text(d['Mã đơn hàng']) and dec(d['Số tiền thu']) is None:continue
        stage.control('THU TIỀN','business')
        order=order_by_number.get(key_text(d['Mã đơn hàng'])); amount=dec(d['Số tiền thu']); pdate=parse_date(d['Ngày thu']); method=clean_text(d['Hình thức thanh toán'])
        if not order or amount is None or amount<=0 or not pdate or not method:
            stage.q('REVIEW_PAYMENT_LINK',ref,'Payment cannot link to an accepted order or has invalid amount/date/method',d);continue
        if key_text(d['Mã KH']) and customer_by_code.get(key_text(d['Mã KH']),{}).get('id')!=order['customer_id']:
            stage.q('REVIEW_PAYMENT_LINK',ref,'Payment customer does not match linked order customer',d);continue
        stage.add('customer_payments',{'id':stable_uuid('customer_payment',ref),'customer_id':order['customer_id'],'sales_order_id':order['id'],'amount':json_num(amount),'payment_date':pdate,'payment_method':method,'status':'POSTED','reference':clean_text(d['Mã phiếu thu']),'note':'Legacy collector: '+clean_text(d['Người thu']) if clean_text(d['Người thu']) else None,'source_row_reference':ref,'legacy_order_total':json_num(dec(d['Tổng đơn hàng']))})

    # Opening inventory / adjustment candidates: stage only, never load in OPS-071.
    adj_headers=['Mã điều chỉnh','Ngày','Loại điều chỉnh','Mã SP','Tên sản phẩm','Số lượng','Ghi chú','Người thực hiện']
    for r,vals,errs in thu.rows('ĐIỀU CHỈNH KHO'):
        if r==1:continue
        d=row_dict(vals,adj_headers); ref=source_ref(SOURCE_IDS['thu_chi'],'ĐIỀU CHỈNH KHO',r)
        if not clean_text(d['Loại điều chỉnh']) and dec(d['Số lượng']) is None:continue
        stage.control('ĐIỀU CHỈNH KHO','business'); q=dec(d['Số lượng']); typ=clean_text(d['Loại điều chỉnh']); v=resolve_variant(d['Mã SP'],d['Tên sản phẩm'],None,ref)
        rec={'id':stable_uuid('opening_candidate',ref),'product_variant_id':v['id'] if v else None,'candidate_type':typ,'quantity':json_num(q),'event_date':parse_date(d['Ngày']),'notes':clean_text(d['Ghi chú']),'source_row_reference':ref}
        stage.add('opening_inventory_candidates',rec)
        stage.q('REVIEW_OPENING_BALANCE',ref,'Opening/adjustment candidate requires OPS-072 reconciliation',rec)
        if q is not None and q<0:stage.q('REVIEW_NEGATIVE_STOCK',ref,'Negative opening/adjustment quantity preserved for reconciliation',rec)

    thu.close(); gia.close()

    # Controls / outputs
    for entity,rows in stage.records.items():
        with open(out/(entity+'.jsonl'),'w',encoding='utf-8') as f:
            for row in rows:f.write(json.dumps(row,ensure_ascii=False,sort_keys=True,default=json_default)+'\n')
    with open(out/'quarantine.jsonl','w',encoding='utf-8') as f:
        for row in stage.quarantine:f.write(json.dumps(row,ensure_ascii=False,sort_keys=True,default=json_default)+'\n')
    with open(out/'status_values.json','w',encoding='utf-8') as f:json.dump(dict(stage.status_values),f,ensure_ascii=False,indent=2,sort_keys=True,default=json_default)
    summary={
      'task_id':'OPS-071','snapshot':snapshot_meta,
      'entity_counts':{k:len(v) for k,v in sorted(stage.records.items())},
      'quarantine_count':len(stage.quarantine),
      'quarantine_by_reason':dict(sorted(Counter(q['reason'] for q in stage.quarantine).items())),
      'source_controls':{sheet:{kind:n for (s,kind),n in stage.controls.items() if s==sheet} for sheet in sorted({s for s,_ in stage.controls})},
      'status_values':dict(stage.status_values),
      'invariants':{
        'all_source_refs_present':all(r.get('source_row_reference') or r.get('source_reference') for rows in stage.records.values() for r in rows),
        'quarantine_reason_codes_valid':all(q['reason'] in QUARANTINE_CODES for q in stage.quarantine),
        'payment_identity_is_source_row_reference':True,
        'opening_inventory_not_loaded':True,
        'pricing_blocks_not_guessed':True,
      }
    }
    with open(out/'reconciliation_inputs.json','w',encoding='utf-8') as f:json.dump(summary,f,ensure_ascii=False,indent=2,sort_keys=True,default=json_default)
    return summary

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--thu-chi',required=True);ap.add_argument('--gia-von',required=True);ap.add_argument('--output-dir',required=True)
    ap.add_argument('--source-modified-thu',required=True);ap.add_argument('--source-modified-gia',required=True)
    ap.add_argument('--exported-at',default='2026-10-01T12:00:00+07:00')
    args=ap.parse_args()
    thu=Path(args.thu_chi);gia=Path(args.gia_von)
    meta={
      'exported_at':args.exported_at,
      'effective_at':'2026-10-01T05:00:00Z',
      'sources':[
        {'source_key':'thu_chi','file_id':SOURCE_IDS['thu_chi'],'modified_at':args.source_modified_thu,'file_name':thu.name,'byte_size':thu.stat().st_size,'sha256':sha256_file(thu),'export_format':'xlsx'},
        {'source_key':'gia_von','file_id':SOURCE_IDS['gia_von'],'modified_at':args.source_modified_gia,'file_name':gia.name,'byte_size':gia.stat().st_size,'sha256':sha256_file(gia),'export_format':'xlsx'},
      ]
    }
    summary=run(thu,gia,args.output_dir,meta)
    print(json.dumps(summary,ensure_ascii=False,indent=2,sort_keys=True,default=json_default))
if __name__=='__main__':main()
